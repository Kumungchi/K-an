import { BiometricData, MoodEntry, AIRecommendation } from '../types';

export const generateMockBiometricData = (userId: string, days: number = 7): BiometricData[] => {
  const data: BiometricData[] = [];
  
  for (let i = 0; i < days; i++) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    data.push({
      id: `bio-${userId}-${i}`,
      userId,
      date,
      sleep: {
        duration: 6.5 + Math.random() * 2, // 6.5-8.5 hours
        quality: 60 + Math.random() * 40, // 60-100%
        deepSleep: 1.2 + Math.random() * 0.8, // 1.2-2 hours
      },
      activity: {
        steps: 3000 + Math.random() * 7000, // 3k-10k steps
        activeMinutes: 20 + Math.random() * 40, // 20-60 minutes
        calories: 1800 + Math.random() * 400, // 1800-2200 calories
      },
      hrv: 30 + Math.random() * 40, // 30-70 ms
      screenTime: 4 + Math.random() * 6, // 4-10 hours
    });
  }
  
  return data.reverse();
};

export const generateMockMoodData = (userId: string, days: number = 7): MoodEntry[] => {
  const data: MoodEntry[] = [];
  
  for (let i = 0; i < days; i++) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    // Create some realistic mood patterns
    const baseValence = -0.2 + Math.random() * 0.8; // Slightly positive bias
    const baseArousal = -0.3 + Math.random() * 0.6; // Slightly calm bias
    
    data.push({
      id: `mood-${userId}-${i}`,
      userId,
      valence: Math.max(-1, Math.min(1, baseValence + (Math.random() - 0.5) * 0.4)),
      arousal: Math.max(-1, Math.min(1, baseArousal + (Math.random() - 0.5) * 0.4)),
      timestamp: date,
      note: i === 0 ? 'Feeling reflective today' : undefined,
    });
  }
  
  return data.reverse();
};

export const generateAIRecommendations = (
  moodData: MoodEntry[],
  biometricData: BiometricData[]
): AIRecommendation[] => {
  const recommendations: AIRecommendation[] = [];
  const userId = moodData[0]?.userId || 'anonymous';
  
  const latestMood = moodData[moodData.length - 1];
  const latestBiometric = biometricData[biometricData.length - 1];
  
  if (!latestMood || !latestBiometric) return recommendations;
  
  // Low energy + low mood
  if (latestMood.valence < -0.3 && latestMood.arousal < -0.3) {
    recommendations.push({
      id: `rec-${Date.now()}-1`,
      userId,
      type: 'movement',
      title: 'Gentle Movement',
      message: 'A short 10-minute walk might help lift your energy. Fresh air and movement can naturally boost your mood.',
      priority: 'medium',
      timestamp: new Date(),
    });
  }
  
  // High screen time
  if (latestBiometric.screenTime > 8) {
    recommendations.push({
      id: `rec-${Date.now()}-2`,
      userId,
      type: 'environment',
      title: 'Digital Break',
      message: 'You\'ve spent quite a bit of time on screens today. Consider dimming your display or taking a 20-minute break.',
      priority: 'medium',
      timestamp: new Date(),
    });
  }
  
  // Poor sleep quality
  if (latestBiometric.sleep.quality < 70) {
    recommendations.push({
      id: `rec-${Date.now()}-3`,
      userId,
      type: 'rest',
      title: 'Sleep Preparation',
      message: 'Your sleep quality could improve. Try creating a calming bedtime routine 1 hour before sleep.',
      priority: 'high',
      timestamp: new Date(),
    });
  }
  
  // High arousal (stressed/anxious)
  if (latestMood.arousal > 0.5) {
    recommendations.push({
      id: `rec-${Date.now()}-4`,
      userId,
      type: 'mindfulness',
      title: 'Breathing Exercise',
      message: 'You seem energized, but it might help to center yourself. Try 4-7-8 breathing for a few minutes.',
      priority: 'medium',
      timestamp: new Date(),
    });
  }
  
  // Low activity
  if (latestBiometric.activity.steps < 4000) {
    recommendations.push({
      id: `rec-${Date.now()}-5`,
      userId,
      type: 'movement',
      title: 'Movement Reminder',
      message: 'Your body might enjoy some gentle movement today. Even stretching or dancing to one song helps.',
      priority: 'low',
      timestamp: new Date(),
    });
  }
  
  return recommendations;
};