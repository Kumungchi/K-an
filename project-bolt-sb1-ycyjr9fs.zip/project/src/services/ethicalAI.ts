import { MoodEntry, HealthData, SocialMediaData, AIRecommendation, EthicalSettings } from '../types';

export class EthicalAIService {
  private static instance: EthicalAIService;
  
  static getInstance(): EthicalAIService {
    if (!EthicalAIService.instance) {
      EthicalAIService.instance = new EthicalAIService();
    }
    return EthicalAIService.instance;
  }

  // Core ethical principles
  private ethicalPrinciples = {
    userWellbeingFirst: true,
    transparentRecommendations: true,
    respectUserAutonomy: true,
    noManipulativeDesign: true,
    dataMinimization: true,
    consentBased: true,
  };

  async generateEthicalRecommendations(
    userId: string,
    moodData: MoodEntry[],
    healthData: HealthData[],
    socialData: SocialMediaData[],
    ethicalSettings: EthicalSettings
  ): Promise<AIRecommendation[]> {
    
    // Check if user has reached daily engagement limit
    if (await this.hasReachedDailyLimit(userId, ethicalSettings)) {
      return this.generateDisengagementRecommendation(userId);
    }

    const recommendations: AIRecommendation[] = [];
    const context = this.analyzeUserContext(moodData, healthData, socialData);
    
    // Generate recommendations based on ethical AI principles
    if (context.needsRest && !context.isInDoNotDisturb) {
      recommendations.push(await this.createRestRecommendation(userId, context));
    }

    if (context.digitalOverload) {
      recommendations.push(await this.createDigitalWellnessRecommendation(userId, context));
    }

    if (context.socialMediaOveruse) {
      recommendations.push(await this.createMindfulConsumptionRecommendation(userId, context));
    }

    if (context.positiveEngagement) {
      recommendations.push(await this.createPositiveReinforcementRecommendation(userId, context));
    }

    // Filter recommendations through ethical lens
    return this.applyEthicalFilters(recommendations, ethicalSettings);
  }

  private analyzeUserContext(
    moodData: MoodEntry[],
    healthData: HealthData[],
    socialData: SocialMediaData[]
  ) {
    const latestMood = moodData[moodData.length - 1];
    const latestHealth = healthData[healthData.length - 1];
    const recentSocial = socialData.slice(-24); // Last 24 hours

    return {
      currentMood: latestMood,
      stressLevel: latestHealth?.stress || 0,
      sleepQuality: latestHealth?.sleep?.quality || 100,
      socialMediaTime: recentSocial.reduce((sum, data) => sum + data.timeSpent, 0),
      contentSentiment: this.calculateAverageContentSentiment(recentSocial),
      needsRest: this.assessRestNeed(latestMood, latestHealth),
      digitalOverload: this.assessDigitalOverload(recentSocial),
      socialMediaOveruse: this.assessSocialMediaOveruse(recentSocial),
      positiveEngagement: this.assessPositiveEngagement(latestMood, recentSocial),
      isInDoNotDisturb: this.checkDoNotDisturbMode(),
    };
  }

  private async createRestRecommendation(userId: string, context: any): Promise<AIRecommendation> {
    return {
      id: `ethical-rest-${Date.now()}`,
      userId,
      type: 'rest',
      title: 'Gentle Rest Suggestion',
      message: 'Your body and mind might benefit from a short break. Consider stepping away from screens for 10-15 minutes.',
      priority: 'medium',
      timestamp: new Date(),
      reasoning: `Based on your recent mood (${context.currentMood?.valence.toFixed(2)}) and stress indicators, a brief rest could help restore balance.`,
      ethicalScore: 95,
      userBenefit: 'Helps prevent burnout and maintains sustainable wellbeing',
      alternativeOptions: [
        'Take a 5-minute breathing break',
        'Go for a short walk',
        'Listen to calming music',
        'Do gentle stretching'
      ],
      respectsLimits: true,
    };
  }

  private async createDigitalWellnessRecommendation(userId: string, context: any): Promise<AIRecommendation> {
    return {
      id: `ethical-digital-${Date.now()}`,
      userId,
      type: 'digital_wellness',
      title: 'Digital Balance Check',
      message: 'You\'ve been quite active digitally today. Consider setting some boundaries to maintain balance.',
      priority: 'medium',
      timestamp: new Date(),
      reasoning: `Your screen time and app usage patterns suggest it might be beneficial to create some digital boundaries.`,
      ethicalScore: 90,
      userBenefit: 'Promotes healthier relationship with technology and reduces digital fatigue',
      alternativeOptions: [
        'Enable Do Not Disturb for 1 hour',
        'Try the 20-20-20 rule (look at something 20 feet away for 20 seconds every 20 minutes)',
        'Switch to grayscale mode',
        'Set app time limits'
      ],
      respectsLimits: true,
    };
  }

  private async createMindfulConsumptionRecommendation(userId: string, context: any): Promise<AIRecommendation> {
    return {
      id: `ethical-mindful-${Date.now()}`,
      userId,
      type: 'content_curation',
      title: 'Mindful Content Consumption',
      message: 'Consider curating your content diet. Quality over quantity can improve your mental state.',
      priority: 'low',
      timestamp: new Date(),
      reasoning: `Your recent content consumption shows patterns that might benefit from more intentional choices.`,
      ethicalScore: 85,
      userBenefit: 'Improves mental clarity and emotional wellbeing through better content choices',
      alternativeOptions: [
        'Unfollow accounts that don\'t add value',
        'Follow accounts focused on your interests and growth',
        'Set specific times for social media',
        'Try a news diet for a day'
      ],
      respectsLimits: true,
    };
  }

  private async createPositiveReinforcementRecommendation(userId: string, context: any): Promise<AIRecommendation> {
    return {
      id: `ethical-positive-${Date.now()}`,
      userId,
      type: 'mindfulness',
      title: 'Celebrating Your Balance',
      message: 'You\'re doing well with maintaining balance today. Keep up the mindful approach!',
      priority: 'low',
      timestamp: new Date(),
      reasoning: 'Your current patterns show healthy balance and mindful engagement.',
      ethicalScore: 100,
      userBenefit: 'Reinforces positive behaviors without creating dependency',
      alternativeOptions: [
        'Reflect on what\'s working well',
        'Share your positive energy with others',
        'Continue your current approach',
        'Set an intention for tomorrow'
      ],
      respectsLimits: true,
    };
  }

  private applyEthicalFilters(
    recommendations: AIRecommendation[],
    ethicalSettings: EthicalSettings
  ): AIRecommendation[] {
    return recommendations.filter(rec => {
      // Only include recommendations that meet ethical standards
      if (rec.ethicalScore < 70) return false;
      if (!rec.respectsLimits) return false;
      if (!ethicalSettings.userControlledRecommendations && rec.priority === 'high') return false;
      
      return true;
    }).slice(0, 3); // Limit to 3 recommendations to avoid overwhelming
  }

  private async hasReachedDailyLimit(userId: string, settings: EthicalSettings): Promise<boolean> {
    // Check if user has spent too much time in the app today
    const todayUsage = await this.getTodayAppUsage(userId);
    return todayUsage > settings.maxDailyEngagement;
  }

  private async getTodayAppUsage(userId: string): Promise<number> {
    // Simulate getting today's app usage
    return Math.random() * 60; // 0-60 minutes
  }

  private generateDisengagementRecommendation(userId: string): AIRecommendation[] {
    return [{
      id: `ethical-disengage-${Date.now()}`,
      userId,
      type: 'digital_wellness',
      title: 'Time for a Break',
      message: 'You\'ve spent enough time in apps today. Consider engaging with the physical world around you.',
      priority: 'high',
      timestamp: new Date(),
      reasoning: 'You\'ve reached your healthy daily limit for digital engagement.',
      ethicalScore: 100,
      userBenefit: 'Prevents digital overconsumption and promotes real-world engagement',
      alternativeOptions: [
        'Go for a walk outside',
        'Call a friend or family member',
        'Read a physical book',
        'Practice a hobby'
      ],
      respectsLimits: true,
    }];
  }

  // Helper methods for context analysis
  private calculateAverageContentSentiment(socialData: SocialMediaData[]): number {
    if (socialData.length === 0) return 0;
    return socialData.reduce((sum, data) => sum + data.contentSentiment, 0) / socialData.length;
  }

  private assessRestNeed(mood: MoodEntry | undefined, health: HealthData | undefined): boolean {
    if (!mood || !health) return false;
    return mood.valence < -0.3 || mood.arousal < -0.4 || (health.stress || 0) > 70;
  }

  private assessDigitalOverload(socialData: SocialMediaData[]): boolean {
    const totalTime = socialData.reduce((sum, data) => sum + data.timeSpent, 0);
    return totalTime > 180; // More than 3 hours
  }

  private assessSocialMediaOveruse(socialData: SocialMediaData[]): boolean {
    const socialTime = socialData
      .filter(data => ['twitter', 'instagram', 'facebook', 'tiktok'].includes(data.platform))
      .reduce((sum, data) => sum + data.timeSpent, 0);
    return socialTime > 120; // More than 2 hours
  }

  private assessPositiveEngagement(mood: MoodEntry | undefined, socialData: SocialMediaData[]): boolean {
    if (!mood) return false;
    const avgSentiment = this.calculateAverageContentSentiment(socialData);
    return mood.valence > 0.2 && avgSentiment > 0.1;
  }

  private checkDoNotDisturbMode(): boolean {
    // Check if user has Do Not Disturb enabled
    const hour = new Date().getHours();
    return hour < 7 || hour > 22; // Assume DND during night hours
  }

  // Ethical gamification - focus on intrinsic motivation
  generateEthicalAchievements(userId: string, weeklyData: any): any[] {
    const achievements = [];

    // Focus on balance, not streaks or competition
    if (weeklyData.balanceDays >= 5) {
      achievements.push({
        id: `balance-week-${Date.now()}`,
        type: 'balance',
        title: 'Balanced Week',
        description: 'You maintained good balance between digital and offline activities',
        earnedAt: new Date(),
        isEthical: true,
      });
    }

    // Celebrate mindful usage, not total usage
    if (weeklyData.mindfulSessions >= 3) {
      achievements.push({
        id: `mindful-week-${Date.now()}`,
        type: 'mindfulness',
        title: 'Mindful Engagement',
        description: 'You practiced mindful technology use this week',
        earnedAt: new Date(),
        isEthical: true,
      });
    }

    return achievements;
  }
}