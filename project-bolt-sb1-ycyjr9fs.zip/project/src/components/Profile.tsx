import React from 'react';
import { User, Shield, Heart, Settings, HelpCircle } from 'lucide-react';

interface ProfileProps {
  user: { email?: string; isAnonymous: boolean };
  onLogout: () => void;
}

export const Profile: React.FC<ProfileProps> = ({ user, onLogout }) => {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-2xl font-light text-white mb-2">Váš profil</h1>
        <p className="text-slate-400">Nastavení a informace o účtu</p>
      </div>

      {/* User Info */}
      <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center">
            <User className="w-8 h-8 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-medium text-white">
              {user.isAnonymous ? 'Anonymní uživatel' : 'Váš účet'}
            </h3>
            <p className="text-slate-400">
              {user.isAnonymous ? 'Přihlášen anonymně' : user.email}
            </p>
          </div>
        </div>
      </div>

      {/* Privacy Section */}
      <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-medium text-white">Soukromí a bezpečnost</h3>
            <p className="text-slate-400 text-sm">Vaše data jsou chráněna</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-xl">
            <div>
              <p className="text-white font-medium">End-to-end šifrování</p>
              <p className="text-slate-400 text-sm">Vaše data jsou šifrována na vašem zařízení</p>
            </div>
            <div className="w-3 h-3 bg-green-400 rounded-full"></div>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-xl">
            <div>
              <p className="text-white font-medium">Žádné prodávání dat</p>
              <p className="text-slate-400 text-sm">Vaše informace nikdy nesdílíme s třetími stranami</p>
            </div>
            <div className="w-3 h-3 bg-green-400 rounded-full"></div>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-xl">
            <div>
              <p className="text-white font-medium">Kontrola nad daty</p>
              <p className="text-slate-400 text-sm">Rozhodujete, co sdílet a co ne</p>
            </div>
            <div className="w-3 h-3 bg-green-400 rounded-full"></div>
          </div>
        </div>
      </div>

      {/* Philosophy */}
      <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-rose-600 rounded-xl flex items-center justify-center">
            <Heart className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-medium text-white">Naše filosofie</h3>
            <p className="text-slate-400 text-sm">Cílem není výkonnost, ale rovnováha</p>
          </div>
        </div>
        
        <div className="prose prose-slate prose-invert max-w-none">
          <p className="text-slate-300 leading-relaxed">
            Kōan podporuje pozornost k sobě, psychohygienu a self-compassion. 
            Nehodnotíme ani nesrovnáváme - jen pomáháme včas zachytit vychýlení 
            z rovnováhy dřív, než přeroste v krizi.
          </p>
        </div>
      </div>

      {/* Settings */}
      <div className="space-y-3">
        <button className="w-full flex items-center justify-between p-4 bg-slate-800/40 backdrop-blur-sm rounded-xl border border-slate-700/30 hover:bg-slate-800/60 transition-all duration-200">
          <div className="flex items-center space-x-3">
            <Settings className="w-5 h-5 text-slate-400" />
            <span className="text-white">Nastavení</span>
          </div>
          <div className="text-slate-400">→</div>
        </button>
        
        <button className="w-full flex items-center justify-between p-4 bg-slate-800/40 backdrop-blur-sm rounded-xl border border-slate-700/30 hover:bg-slate-800/60 transition-all duration-200">
          <div className="flex items-center space-x-3">
            <HelpCircle className="w-5 h-5 text-slate-400" />
            <span className="text-white">Nápověda a podpora</span>
          </div>
          <div className="text-slate-400">→</div>
        </button>
      </div>

      {/* Logout Button */}
      <button
        onClick={onLogout}
        className="w-full bg-red-500/10 hover:bg-red-500/20 text-red-400 hover:text-red-300 py-3 px-4 rounded-xl font-medium transition-all duration-200 border border-red-500/20"
      >
        Odhlásit se
      </button>
    </div>
  );
};