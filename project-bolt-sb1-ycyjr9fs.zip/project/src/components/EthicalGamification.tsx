import React from 'react';
import { 
  Award, 
  Heart, 
  Leaf, 
  Moon, 
  Smile,
  TrendingUp,
  Calendar,
  Target
} from 'lucide-react';
import { Achievement, WellnessMetrics } from '../types';

interface EthicalGamificationProps {
  achievements: Achievement[];
  wellnessMetrics: WellnessMetrics;
  userId: string;
}

export const EthicalGamification: React.FC<EthicalGamificationProps> = ({ 
  achievements, 
  wellnessMetrics 
}) => {
  const getAchievementIcon = (type: Achievement['type']) => {
    switch (type) {
      case 'balance':
        return <Leaf className="w-5 h-5 text-white" />;
      case 'mindfulness':
        return <Heart className="w-5 h-5 text-white" />;
      case 'digital_wellness':
        return <Moon className="w-5 h-5 text-white" />;
      case 'self_care':
        return <Smile className="w-5 h-5 text-white" />;
      default:
        return <Award className="w-5 h-5 text-white" />;
    }
  };

  const getMetricColor = (score: number) => {
    if (score >= 80) return 'from-green-500 to-emerald-600';
    if (score >= 60) return 'from-yellow-500 to-orange-500';
    return 'from-blue-500 to-indigo-600';
  };

  const getMetricMessage = (score: number) => {
    if (score >= 80) return 'Excellent balance';
    if (score >= 60) return 'Good progress';
    return 'Room for growth';
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-light text-white mb-2">Your Wellness Journey</h2>
        <p className="text-slate-400">Celebrating progress, not perfection</p>
      </div>

      {/* Wellness Metrics */}
      <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-medium text-white">Wellness Overview</h3>
            <p className="text-slate-400 text-sm">Your holistic wellbeing snapshot</p>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Overall Balance', value: wellnessMetrics.overallBalance, icon: Target },
            { label: 'Digital Wellness', value: wellnessMetrics.digitalWellness, icon: Moon },
            { label: 'Physical Health', value: wellnessMetrics.physicalWellness, icon: Heart },
            { label: 'Emotional State', value: wellnessMetrics.emotionalWellness, icon: Smile },
          ].map((metric) => {
            const Icon = metric.icon;
            return (
              <div key={metric.label} className="bg-slate-700/30 rounded-xl p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-400 text-xs">{metric.label}</span>
                </div>
                <div className="mb-2">
                  <span className="text-2xl font-light text-white">{metric.value}</span>
                  <span className="text-slate-400 text-sm">/100</span>
                </div>
                <div className="w-full bg-slate-600 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full bg-gradient-to-r ${getMetricColor(metric.value)} transition-all duration-500`}
                    style={{ width: `${metric.value}%` }}
                  />
                </div>
                <p className="text-xs text-slate-500 mt-1">{getMetricMessage(metric.value)}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Achievements */}
      <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-xl flex items-center justify-center">
            <Award className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-medium text-white">Recent Achievements</h3>
            <p className="text-slate-400 text-sm">Celebrating your mindful choices</p>
          </div>
        </div>

        {achievements.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-slate-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Calendar className="w-8 h-8 text-slate-400" />
            </div>
            <p className="text-slate-400">Keep practicing mindful habits</p>
            <p className="text-slate-500 text-sm">Achievements will appear as you build healthy patterns</p>
          </div>
        ) : (
          <div className="space-y-4">
            {achievements.slice(0, 3).map((achievement) => (
              <div
                key={achievement.id}
                className="flex items-center space-x-4 p-4 bg-slate-700/30 rounded-xl"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-xl flex items-center justify-center">
                  {getAchievementIcon(achievement.type)}
                </div>
                <div className="flex-1">
                  <h4 className="text-white font-medium">{achievement.title}</h4>
                  <p className="text-slate-400 text-sm">{achievement.description}</p>
                  <p className="text-slate-500 text-xs mt-1">
                    {new Date(achievement.earnedAt).toLocaleDateString('cs-CZ')}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Ethical Gamification Principles */}
      <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-6">
        <h3 className="text-lg font-medium text-green-400 mb-4">Our Approach to Progress</h3>
        <div className="space-y-3 text-sm text-green-300">
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0" />
            <p><strong>No streaks or pressure:</strong> We celebrate consistency without creating anxiety about "breaking streaks"</p>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0" />
            <p><strong>Progress over perfection:</strong> Small improvements matter more than perfect scores</p>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0" />
            <p><strong>Intrinsic motivation:</strong> Achievements focus on how you feel, not external validation</p>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0" />
            <p><strong>Your pace:</strong> No comparisons with others, only with your past self</p>
          </div>
        </div>
      </div>

      {/* Insights */}
      {wellnessMetrics.insights.length > 0 && (
        <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
          <h3 className="text-lg font-medium text-white mb-4">Personal Insights</h3>
          <div className="space-y-3">
            {wellnessMetrics.insights.map((insight, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 bg-slate-700/20 rounded-lg">
                <div className="w-2 h-2 bg-indigo-400 rounded-full mt-2 flex-shrink-0" />
                <p className="text-slate-300 text-sm">{insight}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};