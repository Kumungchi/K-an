import React from 'react';
import { 
  TrendingUp, 
  Moon, 
  Activity, 
  Smartphone, 
  Heart,
  BarChart3,
  Calendar
} from 'lucide-react';
import { MoodEntry, BiometricData } from '../types';

interface DashboardProps {
  moodData: MoodEntry[];
  biometricData: BiometricData[];
}

export const Dashboard: React.FC<DashboardProps> = ({ moodData, biometricData }) => {
  const latestMood = moodData[moodData.length - 1];
  const latestBiometric = biometricData[biometricData.length - 1];

  const getMoodColor = (valence: number, arousal: number) => {
    if (valence > 0.3 && arousal > 0.3) return 'from-yellow-400 to-orange-500'; // Energetic positive
    if (valence > 0.3 && arousal < -0.3) return 'from-green-400 to-blue-500'; // Calm positive
    if (valence < -0.3 && arousal > 0.3) return 'from-red-400 to-pink-500'; // Energetic negative
    if (valence < -0.3 && arousal < -0.3) return 'from-blue-400 to-indigo-500'; // Calm negative
    return 'from-slate-400 to-slate-500'; // Neutral
  };

  const formatSleepDuration = (hours: number) => {
    const h = Math.floor(hours);
    const m = Math.round((hours - h) * 60);
    return `${h}h ${m}m`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-2xl font-light text-white mb-2">Váš přehled</h1>
        <p className="text-slate-400">
          {new Date().toLocaleDateString('cs-CZ', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </p>
      </div>

      {/* Current Mood */}
      {latestMood && (
        <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className={`w-10 h-10 bg-gradient-to-br ${getMoodColor(latestMood.valence, latestMood.arousal)} rounded-xl flex items-center justify-center`}>
                <Heart className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-white">Aktuální nálada</h3>
                <p className="text-slate-400 text-sm">
                  {new Date(latestMood.timestamp).toLocaleTimeString('cs-CZ', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-700/30 rounded-xl p-4">
              <p className="text-slate-400 text-sm mb-1">Emoční ladění</p>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-gradient-to-r from-red-400 to-green-400 rounded-full"></div>
                <span className="text-white font-medium">
                  {latestMood.valence > 0 ? 'Pozitivní' : latestMood.valence < 0 ? 'Negativní' : 'Neutrální'}
                </span>
              </div>
            </div>
            
            <div className="bg-slate-700/30 rounded-xl p-4">
              <p className="text-slate-400 text-sm mb-1">Energie</p>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-gradient-to-r from-blue-400 to-yellow-400 rounded-full"></div>
                <span className="text-white font-medium">
                  {latestMood.arousal > 0 ? 'Energický' : latestMood.arousal < 0 ? 'Klidný' : 'Vyvážený'}
                </span>
              </div>
            </div>
          </div>

          {latestMood.note && (
            <div className="mt-4 p-4 bg-slate-700/20 rounded-xl border border-slate-600/30">
              <p className="text-slate-300 text-sm italic">"{latestMood.note}"</p>
            </div>
          )}
        </div>
      )}

      {/* Biometric Overview */}
      {latestBiometric && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Sleep */}
          <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
                <Moon className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-white">Spánek</h3>
                <p className="text-slate-400 text-sm">Poslední noc</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Délka</span>
                <span className="text-white font-medium">
                  {formatSleepDuration(latestBiometric.sleep.duration)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Kvalita</span>
                <span className="text-white font-medium">
                  {Math.round(latestBiometric.sleep.quality)}%
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Hluboký spánek</span>
                <span className="text-white font-medium">
                  {formatSleepDuration(latestBiometric.sleep.deepSleep)}
                </span>
              </div>
            </div>
          </div>

          {/* Activity */}
          <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-white">Aktivita</h3>
                <p className="text-slate-400 text-sm">Dnes</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Kroky</span>
                <span className="text-white font-medium">
                  {Math.round(latestBiometric.activity.steps).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Aktivní minuty</span>
                <span className="text-white font-medium">
                  {Math.round(latestBiometric.activity.activeMinutes)} min
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">HRV</span>
                <span className="text-white font-medium">
                  {Math.round(latestBiometric.hrv)} ms
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mood Trend Chart */}
      <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-medium text-white">Průběh nálady</h3>
            <p className="text-slate-400 text-sm">Posledních 7 dní</p>
          </div>
        </div>

        <div className="space-y-4">
          {moodData.slice(-7).map((mood, index) => {
            const date = new Date(mood.timestamp);
            const isToday = date.toDateString() === new Date().toDateString();
            
            return (
              <div key={mood.id} className="flex items-center space-x-4">
                <div className="w-16 text-slate-400 text-sm">
                  {isToday ? 'Dnes' : date.toLocaleDateString('cs-CZ', { day: 'numeric', month: 'short' })}
                </div>
                
                <div className="flex-1 flex items-center space-x-3">
                  {/* Valence bar */}
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-slate-500">Nálada</span>
                      <span className="text-xs text-slate-400">
                        {mood.valence > 0 ? '+' : ''}{(mood.valence * 100).toFixed(0)}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full transition-all duration-300 ${
                          mood.valence >= 0 
                            ? 'bg-gradient-to-r from-green-400 to-emerald-500' 
                            : 'bg-gradient-to-r from-red-400 to-rose-500'
                        }`}
                        style={{ width: `${Math.abs(mood.valence) * 100}%` }}
                      />
                    </div>
                  </div>
                  
                  {/* Arousal bar */}
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-slate-500">Energie</span>
                      <span className="text-xs text-slate-400">
                        {mood.arousal > 0 ? '+' : ''}{(mood.arousal * 100).toFixed(0)}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full transition-all duration-300 ${
                          mood.arousal >= 0 
                            ? 'bg-gradient-to-r from-yellow-400 to-orange-500' 
                            : 'bg-gradient-to-r from-blue-400 to-indigo-500'
                        }`}
                        style={{ width: `${Math.abs(mood.arousal) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Screen Time */}
      {latestBiometric && (
        <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-600 rounded-xl flex items-center justify-center">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-medium text-white">Čas u obrazovky</h3>
              <p className="text-slate-400 text-sm">Dnes</p>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-3xl font-light text-white">
              {formatSleepDuration(latestBiometric.screenTime)}
            </span>
            <div className="text-right">
              <p className="text-slate-400 text-sm">
                {latestBiometric.screenTime > 8 ? 'Nad průměrem' : 'V normálu'}
              </p>
              <div className={`w-3 h-3 rounded-full ${
                latestBiometric.screenTime > 8 ? 'bg-orange-400' : 'bg-green-400'
              }`} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};