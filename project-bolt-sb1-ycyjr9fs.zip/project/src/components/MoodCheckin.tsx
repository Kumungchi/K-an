import React, { useState } from 'react';
import { Heart, Zap, Save, MessageCircle } from 'lucide-react';

interface MoodCheckinProps {
  onSubmit: (mood: { valence: number; arousal: number; note?: string }) => void;
  isLoading?: boolean;
}

export const MoodCheckin: React.FC<MoodCheckinProps> = ({ onSubmit, isLoading = false }) => {
  const [valence, setValence] = useState(0); // -1 to 1 (negative to positive)
  const [arousal, setArousal] = useState(0); // -1 to 1 (calm to energetic)
  const [note, setNote] = useState('');
  const [showNote, setShowNote] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ valence, arousal, note: note.trim() || undefined });
  };

  const getValenceLabel = (val: number) => {
    if (val < -0.5) return 'Negativní';
    if (val < -0.1) return 'Spíše negativní';
    if (val < 0.1) return 'Neutrální';
    if (val < 0.5) return 'Spíše pozitivní';
    return 'Pozitivní';
  };

  const getArousalLabel = (val: number) => {
    if (val < -0.5) return 'Velmi klidný';
    if (val < -0.1) return 'Klidný';
    if (val < 0.1) return 'Vyvážený';
    if (val < 0.5) return 'Energický';
    return 'Velmi energický';
  };

  return (
    <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-br from-rose-500 to-pink-600 rounded-xl flex items-center justify-center">
          <Heart className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-xl font-medium text-white">Jak se dnes cítíte?</h2>
          <p className="text-slate-400 text-sm">Vezměte si chvilku pro sebe</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Valence (Emotional Tone) */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-slate-300">Emoční ladění</label>
            <span className="text-sm text-slate-400">{getValenceLabel(valence)}</span>
          </div>
          <div className="relative">
            <input
              type="range"
              min="-1"
              max="1"
              step="0.1"
              value={valence}
              onChange={(e) => setValence(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer slider-thumb"
            />
            <div className="flex justify-between text-xs text-slate-500 mt-2">
              <span>Negativní</span>
              <span>Neutrální</span>
              <span>Pozitivní</span>
            </div>
          </div>
        </div>

        {/* Arousal (Energy Level) */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-slate-300 flex items-center space-x-2">
              <Zap className="w-4 h-4" />
              <span>Úroveň energie</span>
            </label>
            <span className="text-sm text-slate-400">{getArousalLabel(arousal)}</span>
          </div>
          <div className="relative">
            <input
              type="range"
              min="-1"
              max="1"
              step="0.1"
              value={arousal}
              onChange={(e) => setArousal(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer slider-thumb"
            />
            <div className="flex justify-between text-xs text-slate-500 mt-2">
              <span>Klidný</span>
              <span>Vyvážený</span>
              <span>Energický</span>
            </div>
          </div>
        </div>

        {/* Optional Note */}
        <div className="space-y-4">
          <button
            type="button"
            onClick={() => setShowNote(!showNote)}
            className="flex items-center space-x-2 text-slate-400 hover:text-slate-300 transition-colors duration-200"
          >
            <MessageCircle className="w-4 h-4" />
            <span className="text-sm">Přidat poznámku (volitelné)</span>
          </button>
          
          {showNote && (
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Co vás dnes ovlivňuje? Žádné hodnocení, jen pozornost k sobě..."
              className="w-full p-4 bg-slate-700/50 border border-slate-600 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 resize-none"
              rows={3}
              maxLength={200}
            />
          )}
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white py-3 px-4 rounded-xl font-medium hover:from-indigo-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center space-x-2"
        >
          <Save className="w-5 h-5" />
          <span>{isLoading ? 'Ukládám...' : 'Uložit náladu'}</span>
        </button>
      </form>

      <style jsx>{`
        .slider-thumb::-webkit-slider-thumb {
          appearance: none;
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: linear-gradient(45deg, #6366f1, #8b5cf6);
          cursor: pointer;
          border: 2px solid #1e293b;
          box-shadow: 0 4px 8px rgba(99, 102, 241, 0.3);
        }
        
        .slider-thumb::-moz-range-thumb {
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: linear-gradient(45deg, #6366f1, #8b5cf6);
          cursor: pointer;
          border: 2px solid #1e293b;
          box-shadow: 0 4px 8px rgba(99, 102, 241, 0.3);
        }
      `}</style>
    </div>
  );
};