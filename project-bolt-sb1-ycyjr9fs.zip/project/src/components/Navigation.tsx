import React from 'react';
import { Home, Heart, BarChart3, User, LogOut, Smartphone, Award } from 'lucide-react';

interface NavigationProps {
  currentView: 'dashboard' | 'checkin' | 'profile' | 'connections' | 'wellness';
  onViewChange: (view: 'dashboard' | 'checkin' | 'profile' | 'connections' | 'wellness') => void;
  onLogout: () => void;
  user: { email?: string; isAnonymous: boolean };
}

export const Navigation: React.FC<NavigationProps> = ({ 
  currentView, 
  onViewChange, 
  onLogout, 
  user 
}) => {
  const navItems = [
    { id: 'dashboard' as const, icon: Home, label: 'Přehled' },
    { id: 'checkin' as const, icon: Heart, label: 'Check-in' },
    { id: 'connections' as const, icon: Smartphone, label: 'Připojení' },
    { id: 'wellness' as const, icon: Award, label: 'Wellness' },
    { id: 'profile' as const, icon: User, label: 'Profil' },
  ];

  return (
    <>
      {/* Top Navigation */}
      <nav className="bg-slate-800/50 backdrop-blur-sm border-b border-slate-700/30 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-4 h-4 text-white" />
              </div>
              <h1 className="text-xl font-light text-white">Kōan</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-slate-400 text-sm">
                {user.isAnonymous ? 'Anonymní uživatel' : user.email}
              </div>
              <button
                onClick={onLogout}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700/50 rounded-lg transition-all duration-200"
                title="Odhlásit se"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Bottom Navigation - Mobile */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-slate-800/80 backdrop-blur-sm border-t border-slate-700/30 z-50">
        <div className="flex items-center justify-around h-16 px-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onViewChange(item.id)}
                className={`flex flex-col items-center space-y-1 p-2 rounded-lg transition-all duration-200 ${
                  isActive 
                    ? 'text-indigo-400 bg-indigo-500/10' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Side Navigation - Desktop */}
      <nav className="hidden md:block fixed left-0 top-16 bottom-0 w-64 bg-slate-800/30 backdrop-blur-sm border-r border-slate-700/30 z-40">
        <div className="p-6 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onViewChange(item.id)}
                className={`w-full flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${
                  isActive 
                    ? 'text-white bg-gradient-to-r from-indigo-500 to-purple-600 shadow-lg' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};