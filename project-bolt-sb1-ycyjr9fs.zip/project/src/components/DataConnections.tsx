import React, { useState, useEffect } from 'react';
import { 
  Smartphone, 
  Watch, 
  Heart, 
  Instagram, 
  Twitter, 
  Shield,
  CheckCircle,
  AlertCircle,
  Settings,
  Eye,
  EyeOff
} from 'lucide-react';
import { DataIntegrationService } from '../services/dataIntegration';
import { DataConnection, UserPreferences } from '../types';

interface DataConnectionsProps {
  userId: string;
  preferences: UserPreferences;
  onPreferencesUpdate: (preferences: UserPreferences) => void;
}

export const DataConnections: React.FC<DataConnectionsProps> = ({ 
  userId, 
  preferences, 
  onPreferencesUpdate 
}) => {
  const [connections, setConnections] = useState<DataConnection[]>([]);
  const [isConnecting, setIsConnecting] = useState<string | null>(null);
  const [showPrivacyDetails, setShowPrivacyDetails] = useState(false);

  const dataIntegration = DataIntegrationService.getInstance();

  const availableConnections = [
    {
      id: 'apple_health',
      name: 'Apple Health',
      icon: Heart,
      description: 'Heart rate, sleep, activity, mindfulness minutes',
      category: 'health',
      ethicalUse: 'Data used only for your wellbeing insights, never shared',
    },
    {
      id: 'oura_ring',
      name: 'Oura Ring',
      icon: Watch,
      description: 'Sleep quality, HRV, temperature, activity',
      category: 'health',
      ethicalUse: 'Helps understand your recovery and readiness patterns',
    },
    {
      id: 'device_sensors',
      name: 'Device Sensors',
      icon: Smartphone,
      description: 'Screen brightness, tilt, app usage, battery',
      category: 'device',
      ethicalUse: 'Understands your device interaction patterns for better recommendations',
    },
    {
      id: 'instagram',
      name: 'Instagram',
      icon: Instagram,
      description: 'Time spent, content sentiment (optional)',
      category: 'social',
      ethicalUse: 'Helps balance social media consumption, content stays private',
    },
    {
      id: 'twitter',
      name: 'Twitter/X',
      icon: Twitter,
      description: 'Usage patterns, content sentiment (optional)',
      category: 'social',
      ethicalUse: 'Promotes mindful social media use, no data mining',
    },
  ];

  const handleConnect = async (connectionId: string) => {
    setIsConnecting(connectionId);
    
    try {
      let success = false;
      
      switch (connectionId) {
        case 'apple_health':
          success = await dataIntegration.connectAppleHealth(userId);
          break;
        case 'oura_ring':
          // In real app, this would open OAuth flow
          success = await dataIntegration.connectOuraRing(userId, 'demo_token');
          break;
        case 'device_sensors':
          success = true; // Device sensors are always available
          break;
        case 'instagram':
        case 'twitter':
          success = await dataIntegration.connectSocialMedia(connectionId, userId);
          break;
      }

      if (success) {
        const newConnection: DataConnection = {
          id: `${connectionId}-${userId}`,
          userId,
          source: connectionId,
          isConnected: true,
          lastSync: new Date(),
          permissions: ['read'],
          ethicalUseAgreed: true,
        };
        
        setConnections(prev => [...prev.filter(c => c.source !== connectionId), newConnection]);
      }
    } catch (error) {
      console.error(`Failed to connect ${connectionId}:`, error);
    } finally {
      setIsConnecting(null);
    }
  };

  const handleDisconnect = (connectionId: string) => {
    setConnections(prev => prev.filter(c => c.source !== connectionId));
  };

  const updateDataSharingPreference = (key: keyof UserPreferences['dataSharing'], value: boolean) => {
    const updatedPreferences = {
      ...preferences,
      dataSharing: {
        ...preferences.dataSharing,
        [key]: value,
      },
    };
    onPreferencesUpdate(updatedPreferences);
  };

  const isConnected = (connectionId: string) => {
    return connections.some(c => c.source === connectionId && c.isConnected);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-light text-white mb-2">Data Connections</h2>
        <p className="text-slate-400">Connect your data sources for personalized insights</p>
      </div>

      {/* Privacy First Notice */}
      <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Shield className="w-6 h-6 text-green-400" />
          <h3 className="text-lg font-medium text-green-400">Privacy First Approach</h3>
        </div>
        <div className="space-y-2 text-sm text-green-300">
          <p>• All data processing happens on your device when possible</p>
          <p>• You control what data is shared and how it's used</p>
          <p>• Data is never sold or used for advertising</p>
          <p>• You can disconnect any source at any time</p>
        </div>
        <button
          onClick={() => setShowPrivacyDetails(!showPrivacyDetails)}
          className="mt-4 flex items-center space-x-2 text-green-400 hover:text-green-300 transition-colors"
        >
          {showPrivacyDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          <span>{showPrivacyDetails ? 'Hide' : 'Show'} Privacy Details</span>
        </button>
      </div>

      {showPrivacyDetails && (
        <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
          <h4 className="text-white font-medium mb-4">Detailed Privacy Information</h4>
          <div className="space-y-4 text-sm text-slate-300">
            <div>
              <h5 className="text-white font-medium">Data Processing</h5>
              <p>Most analysis happens locally on your device. Only anonymized insights are processed in the cloud.</p>
            </div>
            <div>
              <h5 className="text-white font-medium">Data Retention</h5>
              <p>You can choose how long to keep your data: minimal (7 days), standard (30 days), or extended (1 year).</p>
            </div>
            <div>
              <h5 className="text-white font-medium">Third-Party Access</h5>
              <p>Zero third-party access. No data brokers, no advertising networks, no analytics companies.</p>
            </div>
          </div>
        </div>
      )}

      {/* Data Sharing Preferences */}
      <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30">
        <h3 className="text-lg font-medium text-white mb-4">Data Sharing Preferences</h3>
        <div className="space-y-4">
          {Object.entries(preferences.dataSharing).map(([key, value]) => (
            <div key={key} className="flex items-center justify-between">
              <div>
                <p className="text-white capitalize">{key.replace(/([A-Z])/g, ' $1').toLowerCase()}</p>
                <p className="text-slate-400 text-sm">
                  {key === 'healthData' && 'Heart rate, sleep, activity data'}
                  {key === 'socialMedia' && 'Usage patterns and content sentiment'}
                  {key === 'deviceSensors' && 'Screen brightness, tilt, app usage'}
                  {key === 'contentAnalysis' && 'Analysis of consumed content for recommendations'}
                </p>
              </div>
              <button
                onClick={() => updateDataSharingPreference(key as keyof UserPreferences['dataSharing'], !value)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  value ? 'bg-indigo-600' : 'bg-slate-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    value ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Available Connections */}
      <div className="space-y-4">
        <h3 className="text-lg font-medium text-white">Available Connections</h3>
        
        {availableConnections.map((connection) => {
          const Icon = connection.icon;
          const connected = isConnected(connection.id);
          const connecting = isConnecting === connection.id;
          
          return (
            <div
              key={connection.id}
              className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    connected ? 'bg-green-500/20' : 'bg-slate-700/50'
                  }`}>
                    <Icon className={`w-6 h-6 ${connected ? 'text-green-400' : 'text-slate-400'}`} />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <h4 className="text-white font-medium">{connection.name}</h4>
                      {connected && <CheckCircle className="w-4 h-4 text-green-400" />}
                    </div>
                    <p className="text-slate-400 text-sm mb-2">{connection.description}</p>
                    <p className="text-slate-500 text-xs">{connection.ethicalUse}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {connected ? (
                    <>
                      <button
                        onClick={() => handleDisconnect(connection.id)}
                        className="px-4 py-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all duration-200"
                      >
                        Disconnect
                      </button>
                      <Settings className="w-4 h-4 text-slate-400" />
                    </>
                  ) : (
                    <button
                      onClick={() => handleConnect(connection.id)}
                      disabled={connecting}
                      className="px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {connecting ? 'Connecting...' : 'Connect'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Ethical AI Notice */}
      <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-2xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <AlertCircle className="w-6 h-6 text-indigo-400" />
          <h3 className="text-lg font-medium text-indigo-400">Ethical AI Promise</h3>
        </div>
        <div className="space-y-2 text-sm text-indigo-300">
          <p>• Our AI is designed to help you, not to manipulate or create dependency</p>
          <p>• Recommendations are transparent - you'll always know why we suggest something</p>
          <p>• We respect your time and attention limits</p>
          <p>• You're always in control of your data and recommendations</p>
        </div>
      </div>
    </div>
  );
};