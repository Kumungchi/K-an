import React from 'react';
import { 
  Lightbulb, 
  Heart, 
  Wind, 
  Moon, 
  TreePine, 
  Users,
  Sparkles,
  Clock
} from 'lucide-react';
import { AIRecommendation } from '../types';

interface RecommendationsProps {
  recommendations: AIRecommendation[];
}

const getRecommendationIcon = (type: AIRecommendation['type']) => {
  switch (type) {
    case 'movement':
      return <Wind className="w-5 h-5 text-white" />;
    case 'rest':
      return <Moon className="w-5 h-5 text-white" />;
    case 'mindfulness':
      return <Heart className="w-5 h-5 text-white" />;
    case 'environment':
      return <TreePine className="w-5 h-5 text-white" />;
    case 'social':
      return <Users className="w-5 h-5 text-white" />;
    default:
      return <Sparkles className="w-5 h-5 text-white" />;
  }
};

const getRecommendationColor = (priority: AIRecommendation['priority']) => {
  switch (priority) {
    case 'high':
      return 'from-red-500 to-rose-600';
    case 'medium':
      return 'from-yellow-500 to-orange-600';
    case 'low':
      return 'from-blue-500 to-indigo-600';
    default:
      return 'from-slate-500 to-slate-600';
  }
};

const getPriorityText = (priority: AIRecommendation['priority']) => {
  switch (priority) {
    case 'high':
      return 'Doporučení';
    case 'medium':
      return 'Návrh';
    case 'low':
      return 'Tip';
    default:
      return 'Poznámka';
  }
};

export const Recommendations: React.FC<RecommendationsProps> = ({ recommendations }) => {
  if (recommendations.length === 0) {
    return (
      <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-8 border border-slate-700/30 text-center">
        <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Heart className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-xl font-medium text-white mb-2">Vše vypadá dobře</h3>
        <p className="text-slate-400">
          Vaše aktuální stav je vyvážený. Pokračujte v péči o sebe.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
          <Lightbulb className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-xl font-medium text-white">Jemná doporučení</h2>
          <p className="text-slate-400 text-sm">Návrhy pro vaši pohodu</p>
        </div>
      </div>

      {recommendations.map((recommendation) => (
        <div
          key={recommendation.id}
          className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30 hover:bg-slate-800/60 transition-all duration-300"
        >
          <div className="flex items-start space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-br ${getRecommendationColor(recommendation.priority)} rounded-xl flex items-center justify-center flex-shrink-0`}>
              {getRecommendationIcon(recommendation.type)}
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-medium text-white">
                  {recommendation.title}
                </h3>
                <div className="flex items-center space-x-2 text-slate-400">
                  <span className="text-xs bg-slate-700/50 px-2 py-1 rounded-full">
                    {getPriorityText(recommendation.priority)}
                  </span>
                  <Clock className="w-4 h-4" />
                  <span className="text-xs">
                    {new Date(recommendation.timestamp).toLocaleTimeString('cs-CZ', {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
              </div>
              
              <p className="text-slate-300 leading-relaxed">
                {recommendation.message}
              </p>
            </div>
          </div>
        </div>
      ))}

      <div className="mt-8 p-4 bg-slate-700/20 rounded-xl border border-slate-600/30">
        <p className="text-slate-400 text-sm text-center leading-relaxed">
          <span className="text-indigo-400">💙</span> Tato doporučení jsou pouze návrhy. 
          Naslouchejte svému tělu a udělejte jen to, co vám připadá správné.
        </p>
      </div>
    </div>
  );
};