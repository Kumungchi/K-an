import React, { useState, useEffect } from 'react';
import { Login } from './components/Login';
import { Navigation } from './components/Navigation';
import { Dashboard } from './components/Dashboard';
import { MoodCheckin } from './components/MoodCheckin';
import { Recommendations } from './components/Recommendations';
import { Profile } from './components/Profile';
import { DataConnections } from './components/DataConnections';
import { EthicalGamification } from './components/EthicalGamification';
import { 
  User, 
  MoodEntry, 
  HealthData, 
  SocialMediaData, 
  AIRecommendation,
  UserPreferences,
  EthicalSettings,
  WellnessMetrics,
  Achievement
} from './types';
import { generateMockBiometricData, generateMockMoodData, generateAIRecommendations } from './utils/dataGenerator';
import { EthicalAIService } from './services/ethicalAI';

type ViewType = 'dashboard' | 'checkin' | 'profile' | 'connections' | 'wellness';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [moodData, setMoodData] = useState<MoodEntry[]>([]);
  const [healthData, setHealthData] = useState<HealthData[]>([]);
  const [socialMediaData, setSocialMediaData] = useState<SocialMediaData[]>([]);
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>([]);
  const [wellnessMetrics, setWellnessMetrics] = useState<WellnessMetrics | null>(null);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const ethicalAI = EthicalAIService.getInstance();

  // Default user preferences emphasizing privacy and ethical use
  const defaultPreferences: UserPreferences = {
    dataSharing: {
      healthData: false,
      socialMedia: false,
      deviceSensors: false,
      contentAnalysis: false,
    },
    notifications: {
      gentleReminders: true,
      wellnessCheckins: true,
      breakSuggestions: true,
    },
    privacy: {
      dataRetention: 'minimal',
      anonymizeData: true,
    },
  };

  const defaultEthicalSettings: EthicalSettings = {
    maxDailyEngagement: 30, // 30 minutes max per day
    respectDoNotDisturb: true,
    pauseOnStress: true,
    transparentAlgorithm: true,
    userControlledRecommendations: true,
  };

  useEffect(() => {
    if (user) {
      // Generate initial mock data
      const mockHealth = generateMockBiometricData(user.id, 7);
      const mockMood = generateMockMoodData(user.id, 7);
      const mockSocial = generateMockSocialMediaData(user.id, 7);
      
      setHealthData(mockHealth);
      setMoodData(mockMood);
      setSocialMediaData(mockSocial);
      
      // Generate ethical AI recommendations
      generateEthicalRecommendations(mockMood, mockHealth, mockSocial);
      
      // Generate wellness metrics
      generateWellnessMetrics(mockMood, mockHealth, mockSocial);
    }
  }, [user]);

  const generateMockSocialMediaData = (userId: string, days: number): SocialMediaData[] => {
    const data: SocialMediaData[] = [];
    const platforms: SocialMediaData['platform'][] = ['twitter', 'instagram', 'facebook', 'tiktok'];
    
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      
      platforms.forEach(platform => {
        data.push({
          id: `social-${userId}-${platform}-${i}`,
          userId,
          platform,
          timestamp: date,
          timeSpent: Math.random() * 60, // 0-60 minutes
          interactions: Math.floor(Math.random() * 50),
          contentSentiment: -0.3 + Math.random() * 0.8, // Slightly negative to positive
          contentTypes: ['text', 'image', 'video'].filter(() => Math.random() > 0.5),
          engagementPattern: ['passive', 'active', 'reactive'][Math.floor(Math.random() * 3)] as any,
        });
      });
    }
    
    return data;
  };

  const generateEthicalRecommendations = async (
    moodData: MoodEntry[],
    healthData: HealthData[],
    socialData: SocialMediaData[]
  ) => {
    if (!user) return;
    
    const ethicalRecommendations = await ethicalAI.generateEthicalRecommendations(
      user.id,
      moodData,
      healthData,
      socialData,
      user.ethicalSettings
    );
    
    setRecommendations(ethicalRecommendations);
  };

  const generateWellnessMetrics = (
    moodData: MoodEntry[],
    healthData: HealthData[],
    socialData: SocialMediaData[]
  ) => {
    if (!user) return;

    const latestMood = moodData[moodData.length - 1];
    const latestHealth = healthData[healthData.length - 1];
    const recentSocial = socialData.slice(-7);

    const avgMoodValence = moodData.reduce((sum, mood) => sum + mood.valence, 0) / moodData.length;
    const avgSleepQuality = healthData.reduce((sum, health) => sum + (health.sleep?.quality || 0), 0) / healthData.length;
    const totalSocialTime = recentSocial.reduce((sum, social) => sum + social.timeSpent, 0);

    const metrics: WellnessMetrics = {
      id: `wellness-${user.id}-${Date.now()}`,
      userId: user.id,
      date: new Date(),
      overallBalance: Math.round(60 + (avgMoodValence * 20) + (avgSleepQuality * 0.2)),
      digitalWellness: Math.round(Math.max(20, 100 - (totalSocialTime / 10))),
      physicalWellness: Math.round(avgSleepQuality + (Math.random() * 20)),
      emotionalWellness: Math.round(60 + (avgMoodValence * 30)),
      socialWellness: Math.round(50 + Math.random() * 30),
      insights: [
        'Your sleep quality has been consistent this week',
        'Consider balancing screen time with offline activities',
        'Your mood tracking shows good self-awareness',
      ],
      achievements: [],
    };

    setWellnessMetrics(metrics);

    // Generate ethical achievements
    const weeklyData = {
      balanceDays: Math.floor(Math.random() * 7),
      mindfulSessions: Math.floor(Math.random() * 5),
    };

    const newAchievements = ethicalAI.generateEthicalAchievements(user.id, weeklyData);
    setAchievements(newAchievements);
  };

  const handleLogin = (loginData: { email?: string; isAnonymous: boolean }) => {
    const newUser: User = {
      id: loginData.isAnonymous ? `anon-${Date.now()}` : `user-${Date.now()}`,
      email: loginData.email,
      isAnonymous: loginData.isAnonymous,
      createdAt: new Date(),
      preferences: defaultPreferences,
      ethicalSettings: defaultEthicalSettings,
    };
    
    setUser(newUser);
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('dashboard');
    setMoodData([]);
    setHealthData([]);
    setSocialMediaData([]);
    setRecommendations([]);
    setWellnessMetrics(null);
    setAchievements([]);
  };

  const handleMoodSubmit = async (moodInput: { valence: number; arousal: number; note?: string }) => {
    if (!user) return;
    
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newMoodEntry: MoodEntry = {
      id: `mood-${user.id}-${Date.now()}`,
      userId: user.id,
      valence: moodInput.valence,
      arousal: moodInput.arousal,
      timestamp: new Date(),
      note: moodInput.note,
    };
    
    const updatedMoodData = [...moodData, newMoodEntry];
    setMoodData(updatedMoodData);
    
    // Regenerate ethical recommendations based on new mood data
    await generateEthicalRecommendations(updatedMoodData, healthData, socialMediaData);
    
    // Update wellness metrics
    generateWellnessMetrics(updatedMoodData, healthData, socialMediaData);
    
    setIsLoading(false);
    setCurrentView('dashboard');
  };

  const handlePreferencesUpdate = (newPreferences: UserPreferences) => {
    if (user) {
      setUser({ ...user, preferences: newPreferences });
    }
  };

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <div className="space-y-8">
            <Dashboard moodData={moodData} biometricData={healthData} />
            <Recommendations recommendations={recommendations} />
          </div>
        );
      case 'checkin':
        return <MoodCheckin onSubmit={handleMoodSubmit} isLoading={isLoading} />;
      case 'connections':
        return (
          <DataConnections 
            userId={user.id}
            preferences={user.preferences}
            onPreferencesUpdate={handlePreferencesUpdate}
          />
        );
      case 'wellness':
        return wellnessMetrics ? (
          <EthicalGamification 
            achievements={achievements}
            wellnessMetrics={wellnessMetrics}
            userId={user.id}
          />
        ) : (
          <div className="text-center text-slate-400">Loading wellness data...</div>
        );
      case 'profile':
        return <Profile user={user} onLogout={handleLogout} />;
      default:
        return <Dashboard moodData={moodData} biometricData={healthData} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <Navigation
        currentView={currentView}
        onViewChange={setCurrentView}
        onLogout={handleLogout}
        user={user}
      />
      
      <main className="md:ml-64 pt-16 pb-20 md:pb-8">
        <div className="max-w-4xl mx-auto p-4 md:p-6">
          {renderCurrentView()}
        </div>
      </main>
    </div>
  );
}

export default App;