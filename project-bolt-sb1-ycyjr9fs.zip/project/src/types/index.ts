export interface User {
  id: string;
  email?: string;
  isAnonymous: boolean;
  createdAt: Date;
  preferences: UserPreferences;
  ethicalSettings: EthicalSettings;
}

export interface UserPreferences {
  dataSharing: {
    healthData: boolean;
    socialMedia: boolean;
    deviceSensors: boolean;
    contentAnalysis: boolean;
  };
  notifications: {
    gentleReminders: boolean;
    wellnessCheckins: boolean;
    breakSuggestions: boolean;
  };
  privacy: {
    dataRetention: 'minimal' | 'standard' | 'extended';
    anonymizeData: boolean;
  };
}

export interface EthicalSettings {
  maxDailyEngagement: number; // minutes
  respectDoNotDisturb: boolean;
  pauseOnStress: boolean;
  transparentAlgorithm: boolean;
  userControlledRecommendations: boolean;
}

export interface MoodEntry {
  id: string;
  userId: string;
  valence: number; // -1 to 1 (negative to positive)
  arousal: number; // -1 to 1 (calm to energetic)
  timestamp: Date;
  note?: string;
  context?: MoodContext;
}

export interface MoodContext {
  location?: string;
  weather?: string;
  socialInteraction?: boolean;
  workContext?: boolean;
}

export interface HealthData {
  id: string;
  userId: string;
  source: 'apple_health' | 'oura' | 'garmin' | 'fitbit' | 'manual';
  timestamp: Date;
  heartRate?: number;
  hrv?: number;
  steps?: number;
  sleep?: SleepData;
  activity?: ActivityData;
  stress?: number; // 0-100
}

export interface SleepData {
  duration: number; // hours
  quality: number; // 0-100
  deepSleep: number; // hours
  remSleep: number; // hours
  bedtime: Date;
  wakeTime: Date;
  sleepEfficiency: number; // percentage
}

export interface ActivityData {
  steps: number;
  activeMinutes: number;
  calories: number;
  distance: number; // km
  workouts: WorkoutSession[];
}

export interface WorkoutSession {
  type: string;
  duration: number; // minutes
  intensity: 'low' | 'moderate' | 'high';
  timestamp: Date;
}

export interface DeviceSensorData {
  id: string;
  userId: string;
  timestamp: Date;
  screenBrightness: number; // 0-100
  screenTilt: number; // degrees
  screenTime: number; // minutes
  appUsage: AppUsageData[];
  batteryLevel: number;
  chargingStatus: boolean;
}

export interface AppUsageData {
  appName: string;
  category: string;
  timeSpent: number; // minutes
  openCount: number;
  lastUsed: Date;
}

export interface SocialMediaData {
  id: string;
  userId: string;
  platform: 'twitter' | 'instagram' | 'facebook' | 'tiktok' | 'linkedin';
  timestamp: Date;
  timeSpent: number; // minutes
  interactions: number;
  contentSentiment: number; // -1 to 1
  contentTypes: string[]; // ['video', 'image', 'text', 'news']
  engagementPattern: 'passive' | 'active' | 'reactive';
}

export interface ContentAnalysis {
  id: string;
  userId: string;
  timestamp: Date;
  contentType: 'news' | 'entertainment' | 'educational' | 'social' | 'work';
  sentiment: number; // -1 to 1
  topics: string[];
  emotionalImpact: 'positive' | 'neutral' | 'negative' | 'mixed';
  consumptionPattern: 'mindful' | 'habitual' | 'compulsive';
}

export interface AIRecommendation {
  id: string;
  userId: string;
  type: 'movement' | 'rest' | 'mindfulness' | 'environment' | 'social' | 'digital_wellness' | 'content_curation';
  title: string;
  message: string;
  priority: 'low' | 'medium' | 'high';
  timestamp: Date;
  reasoning: string; // Transparent explanation
  ethicalScore: number; // 0-100, how ethical/beneficial this recommendation is
  userBenefit: string; // Clear explanation of how this helps the user
  alternativeOptions?: string[]; // Give user choices
  respectsLimits: boolean; // Respects user's time/attention limits
}

export interface WellnessMetrics {
  id: string;
  userId: string;
  date: Date;
  overallBalance: number; // 0-100
  digitalWellness: number; // 0-100
  physicalWellness: number; // 0-100
  emotionalWellness: number; // 0-100
  socialWellness: number; // 0-100
  insights: string[];
  achievements: Achievement[];
}

export interface Achievement {
  id: string;
  type: 'balance' | 'mindfulness' | 'digital_wellness' | 'self_care';
  title: string;
  description: string;
  earnedAt: Date;
  isEthical: boolean; // Only achievements that promote genuine wellbeing
}

export interface DataConnection {
  id: string;
  userId: string;
  source: string;
  isConnected: boolean;
  lastSync: Date;
  permissions: string[];
  ethicalUseAgreed: boolean;
}